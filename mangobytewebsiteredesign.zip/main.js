document.addEventListener('DOMContentLoaded', () => {
    // 0. Opening preloader — simple timed intro before the page reveals
    const preloader = document.getElementById('preloader');
    if (preloader) {
        const countEl = document.getElementById('preloader-count');
        document.body.classList.add('preloading');

        const duration = 1100;
        const start = performance.now();

        function tick(now) {
            const progress = Math.min(1, (now - start) / duration);
            const pct = Math.round(progress * 100);
            if (countEl) countEl.textContent = pct + '%';

            if (progress < 1) {
                requestAnimationFrame(tick);
            } else {
                document.body.classList.remove('preloading');
                preloader.classList.add('hide');
                setTimeout(() => preloader.remove(), 700);
            }
        }
        requestAnimationFrame(tick);
    }

    // 1. Initialize Lenis Smooth Scroll
    const lenis = new Lenis({
        duration: 1.2,
        easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
        smooth: true,
        mouseMultiplier: 1,
    });

    // Keep GSAP ScrollTrigger in sync with Lenis's own smoothed scroll
    // position, and drive Lenis off GSAP's ticker instead of a separate
    // requestAnimationFrame loop. Without this, ScrollTrigger's pinned
    // sections (case studies, process cards) read scroll position a
    // frame or more behind where Lenis has actually scrolled to, which
    // is exactly what let two pinned sections render pinned/overlapping
    // at once.
    lenis.on('scroll', ScrollTrigger.update);
    gsap.ticker.add((time) => {
        lenis.raf(time * 1000);
    });
    gsap.ticker.lagSmoothing(0);

    // 2. Custom Cursor
    const cursor = document.getElementById('cursor');
    if (cursor) {
        document.addEventListener('mousemove', (e) => {
            gsap.to(cursor, {
                x: e.clientX - 10,
                y: e.clientY - 10,
                duration: 0.1
            });
        });

        // Cursor hover effects
        const interactiveElements = document.querySelectorAll('a, button, .service-card-stack, .portfolio-card, .menu-toggle, .overlay-close');
        interactiveElements.forEach(el => {
            el.addEventListener('mouseenter', () => {
                gsap.to(cursor, { scale: 3, opacity: 0.5 });
            });
            el.addEventListener('mouseleave', () => {
                gsap.to(cursor, { scale: 1, opacity: 1 });
            });
        });
    }

    // 3. Theme Toggle Logic
    const themeToggle = document.getElementById('theme-toggle');
    const themeIcon = document.getElementById('theme-icon');
    
    const setTheme = (theme) => {
        const isLight = theme === 'light';
        document.body.classList.toggle('light-theme', isLight);
        
        if (themeToggle) {
            themeToggle.innerHTML = isLight 
                ? '<i data-lucide="moon" id="theme-icon"></i>' 
                : '<i data-lucide="sun" id="theme-icon"></i>';
            if (typeof lucide !== 'undefined') lucide.createIcons();
        }
        
        localStorage.setItem('gsx-theme', theme);
    };

    // Load saved theme
    const savedTheme = localStorage.getItem('gsx-theme') || 'light';
    setTheme(savedTheme);

    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            const currentTheme = document.body.classList.contains('light-theme') ? 'dark' : 'light';
            setTheme(currentTheme);
        });
    }

    // 4. Menu Toggle Logic — Open with hamburger, Close with X inside overlay
    const menuToggleBtn = document.getElementById('menu-toggle-btn');
    const menuOverlay = document.getElementById('menu-overlay');

    function openMenu() {
        if (menuToggleBtn) menuToggleBtn.classList.add('open');
        if (menuToggleBtn) menuToggleBtn.setAttribute('aria-expanded', 'true');
        if (menuOverlay) {
            menuOverlay.classList.add('active');
            menuOverlay.setAttribute('aria-hidden', 'false');
        }
        lenis.stop();
    }

    function closeMenu() {
        if (menuToggleBtn) menuToggleBtn.classList.remove('open');
        if (menuToggleBtn) menuToggleBtn.setAttribute('aria-expanded', 'false');
        if (menuOverlay) {
            menuOverlay.classList.remove('active');
            menuOverlay.setAttribute('aria-hidden', 'true');
        }
        lenis.start();
    }

    // Click hamburger to open
    if (menuToggleBtn) {
        menuToggleBtn.addEventListener('click', () => {
            const isOpen = menuToggleBtn.classList.contains('open');
            if (isOpen) {
                closeMenu();
            } else {
                openMenu();
            }
        });
    }



    // Also close when clicking a nav link inside overlay
    if (menuOverlay) {
        const overlayLinks = menuOverlay.querySelectorAll('.overlay-nav a');
        overlayLinks.forEach(link => {
            link.addEventListener('click', () => {
                closeMenu();
            });
        });
    }

    // Close on Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && menuOverlay && menuOverlay.classList.contains('active')) {
            closeMenu();
        }
    });

    // 5. GSAP Animations
    gsap.registerPlugin(ScrollTrigger);

    // Hero Animations
    const heroTl = gsap.timeline();
    if (document.querySelector('.hero-title')) {
        heroTl.from('.hero-title', { opacity: 0, y: 30, duration: 1, ease: 'power3.out' })
              .from('.hero-sub', { opacity: 0, y: 20, duration: 0.8, ease: 'power3.out' }, '-=0.5')
              .from('.hero-btns', { opacity: 0, y: 20, duration: 0.8, ease: 'power3.out' }, '-=0.5')
              .from('.hero-social-proof', { opacity: 0, y: 20, duration: 0.8, ease: 'power3.out' }, '-=0.3');
    }

    // Counter Animation
    const counters = document.querySelectorAll('.counter');
    counters.forEach(counter => {
        const target = +counter.getAttribute('data-target');
        ScrollTrigger.create({
            trigger: counter,
            start: 'top 90%',
            onEnter: () => {
                let count = 0;
                const updateCount = () => {
                    const increment = target / 100;
                    if (count < target) {
                        count += increment;
                        counter.innerText = Math.ceil(count);
                        setTimeout(updateCount, 10);
                    } else {
                        counter.innerText = target;
                    }
                };
                updateCount();
            }
        });
    });

    // Scroll Reveals for sticky service cards
    const serviceCards = document.querySelectorAll('.service-card-stack');
    serviceCards.forEach(el => {
        gsap.from(el, {
            opacity: 0,
            y: 60,
            duration: 0.8,
            scrollTrigger: {
                trigger: el,
                start: 'top 85%',
                toggleActions: 'play none none none'
            }
        });
    });

    // Scroll Reveals for process cards
    const reveals = document.querySelectorAll('.process-slot');
    reveals.forEach(el => {
        gsap.from(el, {
            opacity: 0,
            y: 50,
            duration: 1,
            scrollTrigger: {
                trigger: el,
                start: 'top 85%',
                toggleActions: 'play none none none'
            }
        });
    });

    // Process cards — pinned horizontal line-up: the section holds in
    // place while vertical scroll slides the row of cards left, until
    // the last one has passed and the section releases. On narrow
    // screens this is skipped in favor of the native horizontal-scroll
    // fallback (overflow-x on .process-pin, set in CSS).
    //
    // Created before the case-studies pin below (matching DOM order —
    // this section sits above it on the page) with anticipatePin set on
    // both: back-to-back pinned sections driven by Lenis's momentum
    // scrolling can otherwise engage/release a frame or two late, which
    // reads as this section's cards and the next section's cards both
    // being visible/pinned at once.
    const processPin = document.getElementById('process-pin');
    const processTrack = document.getElementById('process-cards-track');

    if (processPin && processTrack && window.innerWidth > 768) {
        // Cards slide left under a cursor that isn't moving, so CSS
        // :hover can end up active on whichever card happens to land
        // under it mid-slide — while a card is still fading out from a
        // previous hover, another one glides in and picks up hover too,
        // reading as two cards' reveal animations overlapping. Turning
        // off pointer events on the track for the duration of the slide
        // (plus a short settle delay) means hover can only engage once
        // scrolling has actually stopped.
        let settleTimer = null;
        function suspendHoverDuringScroll() {
            processTrack.classList.add('scrolling');
            clearTimeout(settleTimer);
            settleTimer = setTimeout(() => {
                processTrack.classList.remove('scrolling');
            }, 120);
        }

        ScrollTrigger.create({
            trigger: processPin,
            start: 'top top+=90',
            end: () => `+=${Math.max(0, processTrack.scrollWidth - processPin.offsetWidth)}`,
            pin: true,
            scrub: 1,
            anticipatePin: 1,
            onUpdate: self => {
                const maxX = Math.max(0, processTrack.scrollWidth - processPin.offsetWidth);
                gsap.set(processTrack, { x: -maxX * self.progress });
                suspendHoverDuringScroll();
            }
        });
    }

    // Case studies — infinite arc/spiral carousel (scroll-driven + prev/next buttons)
    const motionPin = document.getElementById('motion-pin');
    const motionCards = motionPin ? Array.from(motionPin.querySelectorAll('.motion-card')) : [];
    const motionPrevBtn = document.getElementById('motion-prev');
    const motionNextBtn = document.getElementById('motion-next');

    if (motionPin && motionCards.length && window.innerWidth > 768) {
        const total = motionCards.length;
        const spread = 15; // degrees between neighboring cards
        const radius = 1000;
        let currentOffset = 0;

        const layoutArc = offset => {
            motionCards.forEach((card, i) => {
                let rel = (i - offset) % total;
                if (rel > total / 2) rel -= total;
                if (rel < -total / 2) rel += total;

                const angle = rel * spread;
                const rad = angle * Math.PI / 180;
                const x = Math.sin(rad) * radius;
                const y = (1 - Math.cos(rad)) * radius * 0.55;
                const rotate = angle * 0.55;
                const absAngle = Math.abs(angle);
                const scale = Math.max(1 - absAngle / 110, 0.6);
                const opacity = Math.max(1 - absAngle / 75, 0.08);
                gsap.set(card, {
                    x, y, rotate, scale, opacity,
                    zIndex: 100 - Math.round(absAngle)
                });
            });
        };

        layoutArc(0);

        ScrollTrigger.create({
            trigger: motionPin,
            start: 'top top+=90',
            end: () => `+=${motionPin.offsetHeight * 2.5}`,
            pin: true,
            scrub: 1,
            anticipatePin: 1,
            onUpdate: self => {
                currentOffset = self.progress * total;
                layoutArc(currentOffset);
            }
        });

        const step = dir => {
            const proxy = { val: currentOffset };
            gsap.to(proxy, {
                val: currentOffset + dir,
                duration: 0.6,
                ease: 'power2.out',
                onUpdate: () => layoutArc(proxy.val),
                onComplete: () => { currentOffset = proxy.val; }
            });
        };

        if (motionPrevBtn) motionPrevBtn.addEventListener('click', () => step(-1));
        if (motionNextBtn) motionNextBtn.addEventListener('click', () => step(1));
    } else if (motionPrevBtn && motionNextBtn) {
        // Mobile fallback: buttons scroll the horizontal strip instead
        const scrollAmount = 260;
        motionPrevBtn.addEventListener('click', () => motionPin.scrollBy({ left: -scrollAmount, behavior: 'smooth' }));
        motionNextBtn.addEventListener('click', () => motionPin.scrollBy({ left: scrollAmount, behavior: 'smooth' }));
    }

    // Testimonials — infinite vertical center-scroll selector
    const testiList = document.getElementById('testimonials-list');
    if (testiList) {
        const originals = Array.from(testiList.querySelectorAll('.testimonials-person'));

        // Triple the list (before/original/after) so there's always real
        // content above and below — no empty gap at the ends, ever.
        const beforeFrag = document.createDocumentFragment();
        originals.forEach(p => beforeFrag.appendChild(p.cloneNode(true)));
        testiList.insertBefore(beforeFrag, testiList.firstChild);

        const afterFrag = document.createDocumentFragment();
        originals.forEach(p => afterFrag.appendChild(p.cloneNode(true)));
        testiList.appendChild(afterFrag);

        const people = Array.from(testiList.querySelectorAll('.testimonials-person'));
        const testiTitle = document.getElementById('testimonial-title');
        const testiText = document.getElementById('testimonial-text');
        const testiUpBtn = document.getElementById('testi-scroll-up');
        const testiDownBtn = document.getElementById('testi-scroll-down');

        const setHeight = testiList.scrollHeight / 3;

        // Start centered on the first real (middle-set) item. Measured via
        // getBoundingClientRect (not offsetTop, which is relative to the
        // nearest positioned ancestor — not necessarily this list) while
        // scrollTop is still 0, so the delta is purely intra-list.
        const firstReal = people[originals.length];
        const listRect0 = testiList.getBoundingClientRect();
        const itemRect0 = firstReal.getBoundingClientRect();
        const relativeTop = itemRect0.top - listRect0.top;
        testiList.scrollTop = relativeTop + itemRect0.height / 2 - testiList.clientHeight / 2;

        const updateActiveTestimonial = () => {
            const listRect = testiList.getBoundingClientRect();
            const centerY = listRect.top + listRect.height / 2;
            let closest = null;
            let closestDist = Infinity;
            people.forEach(person => {
                const r = person.getBoundingClientRect();
                const dist = Math.abs((r.top + r.height / 2) - centerY);
                if (dist < closestDist) {
                    closestDist = dist;
                    closest = person;
                }
            });
            people.forEach(p => p.classList.toggle('active', p === closest));
            if (closest && testiTitle && testiText) {
                testiTitle.textContent = closest.dataset.title;
                testiText.textContent = closest.dataset.text;
            }
        };

        let testiScrollTicking = false;
        testiList.addEventListener('scroll', () => {
            if (testiScrollTicking) return;
            testiScrollTicking = true;
            requestAnimationFrame(() => {
                // Loop correction: jump by exactly one set-height when drifting
                // into the clone regions — content is identical, so it's seamless.
                if (testiList.scrollTop < setHeight) {
                    testiList.scrollTop += setHeight;
                } else if (testiList.scrollTop > setHeight * 2) {
                    testiList.scrollTop -= setHeight;
                }
                updateActiveTestimonial();
                testiScrollTicking = false;
            });
        });

        people.forEach(person => {
            person.addEventListener('click', () => {
                person.scrollIntoView({ behavior: 'smooth', block: 'center' });
            });
        });

        if (testiUpBtn) {
            testiUpBtn.addEventListener('click', () => testiList.scrollBy({ top: -100, behavior: 'smooth' }));
        }
        if (testiDownBtn) {
            testiDownBtn.addEventListener('click', () => testiList.scrollBy({ top: 100, behavior: 'smooth' }));
        }

        updateActiveTestimonial();
    }

    // 6. Draggable Services & Work Sliders
    const servicesSlider = document.getElementById('services-slider-element');
    const workSlider = document.getElementById('work-slider-element');
    
    function initDrag(slider, track, paddingRight = 30) {
        if (!slider) return;
        let isDown = false;
        let startX;
        let scrollLeft;

        slider.addEventListener('mousedown', (e) => {
            isDown = true;
            slider.classList.add('dragging');
            startX = e.pageX - slider.offsetLeft;
            scrollLeft = slider.scrollLeft;
            if (track) track.style.transition = 'none';
        });

        slider.addEventListener('mouseleave', () => {
            isDown = false;
            slider.classList.remove('dragging');
        });

        slider.addEventListener('mouseup', () => {
            isDown = false;
            slider.classList.remove('dragging');
        });

        slider.addEventListener('mousemove', (e) => {
            if (!isDown) return;
            e.preventDefault();
            const x = e.pageX - slider.offsetLeft;
            const walk = (x - startX) * 2;
            slider.scrollLeft = scrollLeft - walk;
        });

        // Touch support
        slider.addEventListener('touchstart', (e) => {
            startX = e.touches[0].pageX - slider.offsetLeft;
            scrollLeft = slider.scrollLeft;
        }, { passive: true });

        slider.addEventListener('touchmove', (e) => {
            const x = e.touches[0].pageX - slider.offsetLeft;
            const walk = (x - startX) * 2;
            slider.scrollLeft = scrollLeft - walk;
        }, { passive: true });

        // Make slider horizontally scrollable
        slider.style.overflowX = 'auto';
        slider.style.scrollbarWidth = 'none'; // Firefox
        slider.style.msOverflowStyle = 'none'; // IE
    }

    if (window.innerWidth <= 768) {
        initDrag(servicesSlider, servicesSlider, 100);
        initDrag(workSlider, workSlider, 100);
    } else {
        initDrag(servicesSlider, servicesSlider, 30);
        initDrag(workSlider, workSlider, 30);
    }

    // 7. FAQ Accordion Logic
    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        question.addEventListener('click', () => {
            // Close other open items
            faqItems.forEach(otherItem => {
                if (otherItem !== item && otherItem.classList.contains('active')) {
                    otherItem.classList.remove('active');
                }
            });
            // Toggle current item
            item.classList.toggle('active');
        });
    });

    // 9. Bar frames — follow cursor height, but only inside their own frame
    // (used for both the footer bars and the hero "50+ businesses" accent card)
    function initInteractiveBars(frame) {
        if (!frame) return;
        const bars = Array.from(frame.querySelectorAll('.bar'));
        const influenceRadius = 160; // px, how far a bar reacts from the cursor's x position

        document.addEventListener('mousemove', (e) => {
            const frameRect = frame.getBoundingClientRect();
            const inside = e.clientX >= frameRect.left && e.clientX <= frameRect.right &&
                            e.clientY >= frameRect.top && e.clientY <= frameRect.bottom;

            if (!inside) {
                if (frame.classList.contains('interactive')) {
                    frame.classList.remove('interactive');
                    bars.forEach(bar => { bar.style.height = ''; bar.style.opacity = ''; });
                }
                return;
            }

            frame.classList.add('interactive');
            const mouseHeightRatio = 1 - (e.clientY - frameRect.top) / frameRect.height; // 0 bottom -> 1 top

            bars.forEach(bar => {
                const barRect = bar.getBoundingClientRect();
                const barCenterX = barRect.left + barRect.width / 2;
                const dist = Math.abs(e.clientX - barCenterX);
                const influence = Math.max(0, 1 - dist / influenceRadius);
                const baseHeight = 15;
                const targetHeight = baseHeight + (mouseHeightRatio * 90) * influence;
                bar.style.height = `${targetHeight}%`;
                bar.style.opacity = String(0.35 + influence * 0.65);
            });
        });

        document.addEventListener('mouseleave', () => {
            frame.classList.remove('interactive');
            bars.forEach(bar => { bar.style.height = ''; bar.style.opacity = ''; });
        });
    }

    initInteractiveBars(document.getElementById('site-footer-bars'));
    initInteractiveBars(document.querySelector('.hero-accent-bars'));

    // Service card image ring: tiles orbit the main photo on a tilted
    // ellipse hugging its right side. Position and z-index are computed
    // here from elapsed time rather than left to a CSS offset-path
    // animation, because a container-level transform (needed to tilt
    // the orbit) traps its children in their own stacking context —
    // no tile inside could ever get a z-index below the photo's, so it
    // could only ever be hidden, never genuinely appear behind it.
    // Setting each tile's z-index directly here instead lets the near
    // half of the loop paint above the photo (fully visible, in front)
    // and the far half paint below it (naturally clipped by the
    // photo's opaque edges — only whatever sticks out past them stays
    // visible), the way a planet's ring actually threads behind and in
    // front of the planet.
    const serviceRings = document.querySelectorAll('.service-img-ring');
    if (serviceRings.length) {
        const ORBIT_MS = 24000;
        const TILT = -25 * Math.PI / 180;

        const ringData = Array.from(serviceRings).map(ring => {
            const cardImg = ring.parentElement.querySelector(':scope > img');
            const tiles = Array.from(ring.querySelectorAll('.ring-img')).map(tile => ({
                el: tile,
                i: parseFloat(tile.style.getPropertyValue('--i')) || 0
            }));
            return { ring, cardImg, tiles, total: tiles.length || 1 };
        });

        function updateServiceRings(time) {
            ringData.forEach(({ ring, cardImg, tiles, total }) => {
                const block = ring.closest('.service-block');
                if (!block || !cardImg || !block.matches(':hover')) return;
                const w = cardImg.offsetWidth;
                const h = cardImg.offsetHeight;
                const rx = w * 0.32;
                const ry = h * 0.68;
                const cx = w * 0.56;
                const cy = h * 0.5;
                tiles.forEach(({ el, i }) => {
                    const phase = ((time / ORBIT_MS) + i / total) % 1;
                    const angle = phase * Math.PI * 2;
                    const ex = Math.cos(angle) * rx;
                    const ey = Math.sin(angle) * ry;
                    const x = cx + ex * Math.cos(TILT) - ey * Math.sin(TILT);
                    const y = cy + ex * Math.sin(TILT) + ey * Math.cos(TILT);
                    el.style.transform = `translate(${x}px, ${y}px)`;
                    el.style.zIndex = ex > 0 ? 3 : 1;
                });
            });
            requestAnimationFrame(updateServiceRings);
        }
        requestAnimationFrame(updateServiceRings);
    }

    // 8. Lucide Icons re-init
    if (typeof lucide !== 'undefined') lucide.createIcons();
});
